<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
//Penmbuatan Database Loan
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('loans', function (Blueprint $table) {
            $table->id();
            $table->date("loan_date");

            $table->unsignedBigInteger("catalog_id")->nullable();
            $table->unsignedBigInteger("user_id")->nullable();
            $table->string("status")->default("not_returned");
            $table->timestamps();

            $table->foreign("catalog_id")->references('id')->on('catalogs')->onDelete('set null');
            $table->foreign("user_id")->references('id')->on('users')->onDelete('set null');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('loans');
    }
};
