<!DOCTYPE html>
<html>
<head>
    <title>Loan Library</title>
</head>
<body>

<div class="container">
    <!-- Pembuatan label dan input text dari Loan -->
    <h1>Loan Library</h1>
    
    <form method="post" action="/loans" style= "display: flex; gap: 20px">
        @csrf
        <label for="loan_date">Loan Date:</label>
        <input type="date" name="loan_date" id="loan_date" required>
        <label for="catalog_id">Catalog Id:</label>
        <input type="text" name="catalog_id" id="catalog_id" required>
        <label for="user_id">User Id:</label>
        <input type="text" name="user_id" id="user_id" required>
        <button type="submit">Submit</button>
    </form>
    <!-- Pembuatan tabel penampil dari loan -->
    <div class="table" style="margin-top: 20px; display: flex; flex-direction: column; width: 100%; gap: 0.5cm">
        <div class="head" style="display: flex; margin-bottom: 10px; gap: 20px; width: 100%;">
            <div class="data" style="width: 10%">ID</div>
            <div class="data" style="width: 10%">Catalog ID</div>
            <div class="data" style="width: 10%">User ID</div>
            <div class="data" style="width: 10%">Loan Date</div>
            <div class="data" style="width: 10%">Return Date</div>
            <div class="data" style="width: 10%">Status</div>
            <div class="data" style="width: 10%">Updating</div>
        </div>
        <!-- Sebagai Penampil data -->
        @foreach ($loans as $loan)
        <form class="body" method="POST" action="{{ route('loans.update', $loan) }}" style="display: flex; gap: 20px; width: 100%;">
            @csrf
            <div class="data" style="width: 10%">{{$loan->id}}</div>
            <div class="data" style="width: 10%">{{$loan->catalog_id}}</div>
            <div class="data" style="width: 10%">{{$loan->user_id}}</div>
            <div class="data" style="width: 10%">{{date('d-m-Y', strtotime($loan->loan_date))}}</div>
            <!-- code penambahan tanggal ke 7 pengembalian buku -->
            <div class="data" style="width: 10%">{{date('d-m-Y', strtotime($loan->loan_date."+ 7 days"))}}</div>
            <div class="data" style="width: 10%">{{$loan->status}}</div>
            <button style="width: 5%" type="submit">Update</button>
        </form>
        @endforeach
    </div>
</div>
</body>
</html>
