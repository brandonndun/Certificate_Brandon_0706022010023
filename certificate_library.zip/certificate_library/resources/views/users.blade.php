<!DOCTYPE html>
<html>
<head>
    <title>To-Do List</title>
</head>
<body>

<div class="container" style="display: flex; flex-direction: column; justify-content: center; align-items: center;">
<!-- Pembuatan label dan input text dari login user (sign up) -->
    <h1>Sign Up</h1>

    <form method="post" action="/users" style="display: flex; justify-content: center; gap: 20px">
        @csrf
        <label for="name">Name:</label>
        <input type="text" name="name" id="name" required>
        <label for="username">Username:</label>
        <input type="text" name="username" id="username" required>
        <label for="password">Password:</label>
        <input type="password" name="password" id="password" required>
        <button type="submit">Submit</button>
    </form>
</div>
</body>
</html>
