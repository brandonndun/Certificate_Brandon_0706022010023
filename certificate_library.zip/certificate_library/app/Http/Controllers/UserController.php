<?php

namespace App\Http\Controllers;
use App\Models\User;
use Illuminate\Http\Request;
use DB;

class UserController extends Controller
{
    //Mengatur Fungsi Jalannya dari Sign in dan Sign UP
    public function index()
    {
        $users = User::all();
        return view ('users', compact('users'));
    }
    public function insert (Request $request)
    {
        User::create([
            'name'=> $request-> name,
            'username'=> $request->username,
            'password'=> $request->password,
        ]);
        return redirect()->route('users.login');
    }
    // code login jika username acc akan mengarah langsung ke catalog book
    public function login (Request $request)
    {
        $check = "SELECT count(*) user FROM users WHERE username='".$request->username."' AND password='".$request->password."';";
        $login = DB::select($check);
        if(($login[0])->user == 1){
            return redirect()->route('catalogs');
        }else{
            return redirect()->route('users.login');
        }
    }
    public function update(User $user)
    {
        $task->update(['completed' => true]);
        return redirect()->route('users');
    }
    public function destroy(User $user)
    {
        $task->delete();
        return redirect()->route('users');
    }
}
