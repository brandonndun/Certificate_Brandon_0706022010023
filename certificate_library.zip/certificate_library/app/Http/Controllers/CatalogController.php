<?php

namespace App\Http\Controllers;
use App\Models\Catalog;
use Illuminate\Http\Request;
use DB;

class CatalogController extends Controller
{
    //Mengatur Fungsi jalannya Controller Dari Catalog
    public function index()
    {
        $catalogs = Catalog::all();
        return view('catalogs', ['catalogs'=>$catalogs]);
    }
    public function insert (Request $request)
    {
        Catalog::create([
            'name'=> $request->name,
            'author'=> $request->author,
        ]);
        return redirect()->route('catalogs');
    }
    public function update(Catalog $catalog)
    {
        $task->update(['completed' => true]);
        return redirect()->route('catalogs');
    }
    //Code deleted button untuk menghapus data yang salah di catalog
    public function delete(Catalog $catalog)
    {
        $delete = "DELETE FROM catalogs WHERE id='".$catalog->id."';";
        
        DB::delete($delete);

        return redirect()->route('catalogs');
    }
}
