<?php

namespace App\Http\Controllers;
use App\Models\Loan;
use Illuminate\Http\Request;
use DB;

class LoanController extends Controller
{
    //Mengatur Fungsi Jalannya dari Loan
    public function index()
    {
        $loans = Loan::all();
        return view('loans', ['loans'=>$loans]);
    }
    public function insert (Request $request)
    //Cek buku yang belum dikembalikan bakalan tidak terinput datanya
    {
        $check = "SELECT count(*) cekbuku FROM loans WHERE catalog_id='".$request->catalog_id."' AND status='not_returned';";
        $login = DB::select($check);
        if(($login[0])->cekbuku >= 1){
            return redirect()->route('loans');
        }else{
            Loan::create([
                'loan_date'=> $request-> loan_date,
                'catalog_id'=> $request->catalog_id,
                'user_id'=> $request-> user_id
            ]);
            return redirect()->route('loans');
        }
    }
    //Pengubahan status peminjaman dan pengembalian buku
    public function update(Loan $loan)
    {
        $loan->update(['status'=>'returned']);
        return redirect()->route('loans');
    }
    public function destroy(Loan $loan)
    {
        $loan->delete();
        return redirect()->route('loans');
    }
}
