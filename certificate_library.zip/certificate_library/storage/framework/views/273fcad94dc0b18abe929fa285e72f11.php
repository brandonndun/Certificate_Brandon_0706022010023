<!DOCTYPE html>
<html>
<head>
    <title>To-Do List</title>
</head>
<body>

<div class="container">
    <!-- Pembuatan label, input, dan button dari Catalog -->
    <h1>Catalogs Book</h1>
    
    <form method="post" action="/catalogs" style="display: flex; gap: 20px">
        <?php echo csrf_field(); ?>
        <label for="name">Book Title</label>
        <input type="text" name="name" id="name" required>
        <label for="author">Author</label>
        <input type="text" name="author" id="author" required>
        <button type="submit">Submit</button>
        <!-- Penyesuaian arah lokasi yang dituju Borrow Book ke Loan menggunakan href -->
        <button onclick="event.preventDefault(); window.location.href = '/loans'">Borrow Book</button>

    </form>
    <!-- Pembuatan tabel beserta css tempat pemanggilan data -->
    <div class="table" style="margin-top: 20px; display: flex; flex-direction: column; width: 100%; gap: 0.5cm">
        <div class="head" style="display: flex; margin-bottom: 10px; gap: 20px; width: 100%;">
            <div class="data" style="width: 20%">ID</div>
            <div class="data" style="width: 20%">Name</div>
            <div class="data" style="width: 20%">Author</div>
        </div>
        <!-- Sebagai penampil data dari Catalog yang di inputkan -->
        <?php $__currentLoopData = $catalogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catalog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form class="body" method="POST" action="<?php echo e(route('catalogs.delete', $catalog)); ?>" style="display: flex; gap: 20px; width: 100%;">
            <?php echo csrf_field(); ?>
            <div class="data" style="width: 20%"><?php echo e($catalog->id); ?></div>
            <div class="data" style="width: 20%"><?php echo e($catalog->name); ?></div>
            <div class="data" style="width: 20%"><?php echo e($catalog->author); ?></div>
            <button style="width: 5%" type="submit">Deleted</button>
        </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\LIBRARY\certificate_library\resources\views/catalogs.blade.php ENDPATH**/ ?>