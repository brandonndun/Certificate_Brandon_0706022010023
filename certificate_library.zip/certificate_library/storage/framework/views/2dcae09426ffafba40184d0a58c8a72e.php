<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>

<div class="container" style="display: flex; flex-direction: column; justify-content: center; align-items: center;">
<!-- Pembuatan label dan input text dari login user (sign in) -->
    <h1>Welcome to Library</h1>

    <form method="post" action="/login" style="display: flex; justify-content: center; gap: 20px">
        <?php echo csrf_field(); ?>
        <label for="username">Username:</label>
        <input type="text" name="username" id="username" required>
        <label for="password">Password:</label>
        <input type="password" name="password" id="password" required>
        <button type="submit">Submit</button>
        <!-- code penentuan arah jalur web dengan menggunakan href  -->
        <button onclick="event.preventDefault(); window.location.href = '/users'">Sign Up</button>
    </form>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\LIBRARY\certificate_library\resources\views/login.blade.php ENDPATH**/ ?>