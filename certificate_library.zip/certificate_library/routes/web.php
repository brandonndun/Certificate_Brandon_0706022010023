<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
use App\Http\Controllers\LoanController;
use App\Http\Controllers\CatalogController;
use App\Http\Controllers\UserController;

Route::get('/loans', [LoanController::class, 'index'])->name('loans');
Route::post('/loans', [LoanController::class, 'insert'])->name('loans.insert');

Route::get('/catalogs', [CatalogController::class, 'index'])->name('catalogs');
Route::post('/catalogs', [CatalogController::class, 'insert'])->name('catalogs.insert');
Route::post('/catalogs/{catalog}', [CatalogController::class, 'delete'])->name('catalogs.delete');

Route::get('/login', function() {
    return view("login");
});
Route::post('/login', [UserController::class, 'login'])->name('users.login');

Route::get('/users', [UserController::class, 'index'])->name('users');
Route::post('/users', [UserController::class, 'insert'])->name('users.insert');

Route::post('/loans/{loan}', [LoanController::class, 'update'])->name('loans.update');
Route::delete('/loans/{loan}', [LoanController::class, 'destroy'])->name('loans.destroy');